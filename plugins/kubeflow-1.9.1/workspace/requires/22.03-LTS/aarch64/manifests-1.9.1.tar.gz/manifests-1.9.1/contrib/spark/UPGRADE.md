# Upgrading
```sh
# Step 1: Update SPARK_OPERATOR_RELEASE_VERSION in Makefile
# Step 2: Create new Spark operator manifest
make spark-operator/base
```