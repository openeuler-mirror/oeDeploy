The contrib directory contains third-party applications maintained externally.

All contrib components must meet the [requirements](https://github.com/kubeflow/manifests/blob/master/proposals/20220926-contrib-component-guidelines.md#component-requirements)
 to be considered active and failure to meet them will result in deprecation and removal from the Kubeflow manifest repository.